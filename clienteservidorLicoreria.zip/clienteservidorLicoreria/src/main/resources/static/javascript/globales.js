// variables globales a usar en la parte cliente
//variables globales
let nombre_login = ""
let idioma = ""

//variables para las plantillas
let plantilla_registrar = ""
let plantilla_login = ""
let plantilla_licores = ""
let plantilla_carrito = ""
let plantilla_checkout_1 = ""
let plantilla_checkout_2 = ""
let plantilla_checkout_3 = ""
let plantilla_checkout_extra = ""