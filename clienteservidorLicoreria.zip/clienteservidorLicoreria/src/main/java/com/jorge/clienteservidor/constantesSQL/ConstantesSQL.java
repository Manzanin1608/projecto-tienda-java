package com.jorge.clienteservidor.constantesSQL;

public class ConstantesSQL {
	public static final String SQL_OBTENER_LICORES_PARA_JSON = " SELECT l.id, l.alcohol, l.marca, l.descripcion, l.precio,l.porcentaje,l.pais_origen,l.nombre FROM licores as l ORDER BY l.id DESC";

	public static final String SQL_OBTENER_PRODUCTOS_CARRITO = " SELECT C.USUARIO_ID,C.CANTIDAD,L.ALCOHOL,L.DESCRIPCION,L.MARCA,L.NOMBRE, L.PAIS_ORIGEN, L.PORCENTAJE, L.PRECIO,L.ID AS LICOR_ID FROM CARRITO AS C, LICORES AS L WHERE C.USUARIO_ID = :usuario_id AND L.ID = C.LICOR_ID";
	
	public static final String SQL_ELIMINAR_PRODUCTO_CARRITO = " DELETE FROM CARRITO WHERE licor_id = :licor_id AND usuario_id = :usuario_id ";
	
	public static final String SQL_VACIAR_CARRITO = "DELETE FROM CARRITO WHERE USUARIO_ID =  :usuario_id ";


}
