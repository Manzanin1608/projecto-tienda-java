package com.jorge.clienteservidor.RESTcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jorge.clienteservidor.RESTcontrollers.datos.ResumenPedidio;
import com.jorge.clienteservidor.servicios.ServicioPedidos;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("pedidosREST/")
public class PedidosREST {

	@Autowired
	private ServicioPedidos servicioPedidos;
	
	@RequestMapping("pasoExtra")
	public String pasoExtra(String fav,HttpServletRequest request) {
		long idUsuario = (long)request.getSession().getAttribute("usuario_id");
		servicioPedidos.procesarPasoExtra(fav, idUsuario);
		return "ok";
		
	}
	
	
	@RequestMapping("paso3")
	public String paso3(HttpServletRequest request) {
		long idUsuario = (long)request.getSession().getAttribute("usuario_id");
		servicioPedidos.confirmarPedido(idUsuario);
		return "ok";
		
	}
	
	@RequestMapping("paso2")
	public ResumenPedidio paso2(String tarjeta,String numero, String titular,HttpServletRequest request) {
		String respuesta = "";
		long idUsuario = (long)request.getSession().getAttribute("usuario_id");
		ResumenPedidio resumen = servicioPedidos.procesarPaso2(tarjeta,numero,titular,idUsuario);
		return resumen;
	}
	
	
	@RequestMapping("paso1")
	public String paso1(String nombre,String direccion,String provincia,String cp,String email,String tel,HttpServletRequest request) {
		String respuesta = "";
		long idUsuario = (long)request.getSession().getAttribute("usuario_id");
		servicioPedidos.procesarPaso1(nombre,direccion,provincia,cp,email,tel,idUsuario);
		respuesta = "ok";
		return respuesta;
	}
	
	
}
