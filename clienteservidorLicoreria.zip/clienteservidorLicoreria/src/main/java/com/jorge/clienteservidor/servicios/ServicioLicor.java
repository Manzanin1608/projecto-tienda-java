package com.jorge.clienteservidor.servicios;

import java.util.List;
import java.util.Map;

import com.jorge.clienteservidor.modelo.Licor;



public interface ServicioLicor {

	void registrarLicor(Licor licor);

	List<Licor> obtenerLicores();

	void borrarLicor(long id);

	void actualizarLicor(Licor licor);

	Licor obtenerLicorPorId(long id);
	
	List<Map<String,Object>> obtenerLicoresParaFormarJson();

}
