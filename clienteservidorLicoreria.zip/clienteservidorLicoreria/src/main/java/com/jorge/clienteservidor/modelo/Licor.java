package com.jorge.clienteservidor.modelo;



import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.jorge.clienteservidor.modelo.Carrito;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity(name = "licores")
@Table(name = "licores")
public class Licor {

	@Size(min = 2,max = 40,message = "Alcohol debe tener entre 5 y 40 caracteres")
	@NotEmpty(message = "Insertar un Alcohol")
	@Pattern(regexp = "[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ']+",message = "solo letras , numeros y espacios")
	private String alcohol;
	@Size(min = 2,max = 40,message = "Nombre debe tener entre 5 y 40 caracteres")
	@NotEmpty(message = "Insertar un Nombre")
	@Pattern(regexp = "[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ']+",message = "solo letras , numeros y espacios")
	private String nombre;
	@Size(min = 2,max = 40,message = "Marca debe tener entre 5 y 40 caracteres")
	@NotEmpty(message = "Insertar un Marca")
	@Pattern(regexp = "[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ']+",message = "solo letras , numeros y espacios")
	private String marca;
	@NotNull(message = "debes insertar un precio")
	@Min(value = 1,message = "el precio minimo es de 1 euro")
	@Max(value = 999,message = "el precio maximo es 999€")
	private double precio;
	@NotNull(message = "debes insertar un precio")
	@Min(value = 1,message = "el porcentaje minimo es de 1 ")
	@Max(value = 100,message = "el porcentaje maximo es 100")
	private double porcentaje;
	private String descripcion;
	@Size(min = 2,max = 40,message = "Pais debe tener entre 5 y 40 caracteres")
	@NotEmpty(message = "Insertar un Pais")
	@Pattern(regexp = "[A-Za-z0-9 áéíóúÁÉÍÓÚñÑ']+",message = "solo letras , numeros y espacios")
	private String pais_origen;
	@Lob
	@Column(name = "imagen_portada", columnDefinition = "LONGBLOB")
	private byte[] imagenPortada;
	@Transient
	private MultipartFile foto;
	
	@OneToMany(mappedBy = "licor")
	private List<Carrito> carritos = new ArrayList<Carrito>();
	
	
	
	@ManyToOne
	@JoinColumn(name = "categoria_id")
	private Categoria categoria;
	
	@Transient
	private long idCategoria;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	
	
	public Licor() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Licor(String alcohol, String nombre, String marca, double precio, double porcentaje, String descripcion,
			String pais_origen) {
		super();
		this.alcohol = alcohol;
		this.nombre = nombre;
		this.marca = marca;
		this.precio = precio;
		this.porcentaje = porcentaje;
		this.descripcion = descripcion;
		this.pais_origen = pais_origen;
	}



	public Licor(String alcohol,String nombre, String marca, double precio, double porcentaje, String descripcion, String pais_origen,
			long id) {
		super();
		this.alcohol = alcohol;
		this.nombre = nombre;
		this.marca = marca;
		this.precio = precio;
		this.porcentaje = porcentaje;
		this.descripcion = descripcion;
		this.pais_origen = pais_origen;
		this.id = id;
	}


	public String getAlcohol() {
		return alcohol;
	}


	public void setAlcohol(String alcohol) {
		this.alcohol = alcohol;
	}
	

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public double getPrecio() {
		return precio;
	}


	public void setPrecio(double precio) {
		this.precio = precio;
	}


	public double getPorcentaje() {
		return porcentaje;
	}


	public void setPorcentaje(double porcentaje) {
		this.porcentaje = porcentaje;
	}


	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public String getPais_origen() {
		return pais_origen;
	}


	public void setPais_origen(String pais) {
		this.pais_origen = pais;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "Licor [alcohol=" + alcohol + ", marca=" + marca + ", precio=" + precio + ", porcentaje=" + porcentaje
				+ ", descripcion=" + descripcion + ", pais=" + pais_origen + ", id=" + id + "]";
	}


	public MultipartFile getFoto() {
		return foto;
	}


	public void setFoto(MultipartFile foto) {
		this.foto = foto;
	}


	public byte[] getImagenPortada() {
		return imagenPortada;
	}


	public void setImagenPortada(byte[] imagenPortada) {
		this.imagenPortada = imagenPortada;
	}



	public List<Carrito> getCarritos() {
		return carritos;
	}



	public void setCarritos(List<Carrito> carritos) {
		this.carritos = carritos;
	}



	public Categoria getCategoria() {
		return categoria;
	}


	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}



	public long getIdCategoria() {
		return idCategoria;
	}



	public void setIdCategoria(long idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	
	
	
}
