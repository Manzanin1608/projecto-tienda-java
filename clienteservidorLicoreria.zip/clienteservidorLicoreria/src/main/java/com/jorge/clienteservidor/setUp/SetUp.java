package com.jorge.clienteservidor.setUp;

public interface SetUp {
	void prepararRegistros();
}
