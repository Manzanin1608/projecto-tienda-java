package com.jorge.clienteservidor.servicios;

import java.util.List;

import com.jorge.clienteservidor.modelo.Categoria;

public interface ServicioCategoria {
	
	List<Categoria> obtenerCategorias();

}
