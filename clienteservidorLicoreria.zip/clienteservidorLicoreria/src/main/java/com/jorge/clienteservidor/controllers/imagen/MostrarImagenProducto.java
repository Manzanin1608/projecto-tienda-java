package com.jorge.clienteservidor.controllers.imagen;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jorge.clienteservidor.servicios.ServicioLicor;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class MostrarImagenProducto {
	
	@Autowired
	private ServicioLicor servicioLicor;
	
	// excepcionalmente este modelo no va devolver un String indicado una vista
	// sino que programaremos manualmente que es lo que se va a devolver al usuario
	
	@RequestMapping("mostrarImagen")
	public void mostrarImagen(@RequestParam("id") Long id, HttpServletResponse response) throws IOException {
		byte[] info = servicioLicor.obtenerLicorPorId(id).getImagenPortada();
		if(info == null) {
			return;
		}
		response.setContentType("image/jpeg, image/jpg, image/png, img/gif");
		response.getOutputStream().write(info);
		response.getOutputStream().close();
	}
	
	
	
}
