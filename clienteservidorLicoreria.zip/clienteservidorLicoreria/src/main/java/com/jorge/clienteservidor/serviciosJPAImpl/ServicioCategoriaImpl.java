package com.jorge.clienteservidor.serviciosJPAImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jorge.clienteservidor.modelo.Categoria;
import com.jorge.clienteservidor.servicios.ServicioCategoria;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;


@Service
@Transactional
public class ServicioCategoriaImpl implements ServicioCategoria{

	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Categoria> obtenerCategorias() {
		// TODO Auto-generated method stub
		return entityManager.createQuery("SELECT c FROM Categoria c").getResultList();
	}

}
