package com.jorge.clienteservidor.serviciosJPAImpl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jorge.clienteservidor.constantesSQL.ConstantesSQL;
import com.jorge.clienteservidor.modelo.Carrito;
import com.jorge.clienteservidor.modelo.Licor;
import com.jorge.clienteservidor.modelo.Usuario;
import com.jorge.clienteservidor.servicios.ServicioCarrito;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TupleElement;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ServicioCarritoImpl implements ServicioCarrito{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void agregarProducto(long idUsuario, long idProducto, int cantidad) {
		//aunque seria mas eficiente lanzar una sql
		Usuario usuario = (Usuario) entityManager.find(Usuario.class, idUsuario);
		 List<Carrito> carrito = usuario.getProductosCarrito();
		 boolean productoEnCarrito = false;
		 //ver si el producto esta en el carrito y en tal caso
		 //incrementar su cantidad
		 for(Carrito pc: carrito) {
			 if(pc.getLicor().getId() == idProducto) {
				 productoEnCarrito = true;
				 pc.setCantidad(pc.getCantidad()+cantidad);
				 entityManager.merge(pc);//actualizamos el registro en carrito;
			 }
		 }
		 //si el produto no esta en el carrito, crear un registro nuevo
		 if(!productoEnCarrito) {
			 Carrito productoCarrito = new Carrito();
			 productoCarrito.setUsuario(usuario);
			 productoCarrito.setLicor(entityManager.find(Licor.class, idProducto));
			 productoCarrito.setCantidad(cantidad);
			 entityManager.persist(productoCarrito);
		 }
		
	}
	
	@Override
	public List<Map<String, Object>> obtenerProductosCarrito(long idUsuario) {
		Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_PRODUCTOS_CARRITO, Tuple.class);
		query.setParameter("usuario_id", idUsuario);
		List<Tuple> tuples = query.getResultList();

		List<Map<String, Object>> resultado = new ArrayList<>();
		for (Tuple tuple : tuples) {
		    Map<String, Object> fila = new HashMap<>();
		    for (TupleElement<?> element : tuple.getElements()) {
		        fila.put(element.getAlias(), tuple.get(element));
		    }
		    resultado.add(fila);
		}
		return resultado;
	}

	@Override
	public void quitarProductoCarrito(long idUsuario, Long idLicor) {
		entityManager.createNativeQuery(ConstantesSQL.SQL_ELIMINAR_PRODUCTO_CARRITO).
			setParameter("usuario_id", idUsuario).setParameter("licor_id", idLicor).executeUpdate();
		
	}

}
