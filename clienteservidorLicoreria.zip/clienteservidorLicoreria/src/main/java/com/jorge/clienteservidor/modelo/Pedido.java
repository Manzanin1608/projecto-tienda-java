package com.jorge.clienteservidor.modelo;


import java.util.ArrayList;
import java.util.List;

import com.jorge.clienteservidor.modelo.ProductoPedido;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Pedido {
	
	//estado indicara si el pedido esta completado o no
	private String estado;
	
	//PASO1
	private String nombreCompleto;
	private String direccion;
	private String provincia;
	private String cp;
	private String telefono;
	private String email;
	@OneToMany(mappedBy = "pedido",fetch = FetchType.EAGER)
	private List<ProductoPedido> productoPedido = new ArrayList<ProductoPedido>();
	@ManyToOne(targetEntity = Usuario.class, optional = false)
	private Usuario usuario;
	//PASO2
	private String tipoTarjeta;
	private String numeroTarjeta;
	private String titularTarjeta;
	//PASOEXTRA
	private String fav;
	
	//PASO3
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCp() {
		return cp;
	}

	public void setCp(String cp) {
		this.cp = cp;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getTipoTarjeta() {
		return tipoTarjeta;
	}

	public void setTipoTarjeta(String tipoTarjeta) {
		this.tipoTarjeta = tipoTarjeta;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getTitularTarjeta() {
		return titularTarjeta;
	}

	public void setTitularTarjeta(String titularTarjeta) {
		this.titularTarjeta = titularTarjeta;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<ProductoPedido> getProductoPedido() {
		return productoPedido;
	}

	public void setProductoPedido(List<ProductoPedido> productoPedido) {
		this.productoPedido = productoPedido;
	}

	public String getFav() {
		return fav;
	}

	public void setFav(String fav) {
		this.fav = fav;
	}
	
	
	
}
