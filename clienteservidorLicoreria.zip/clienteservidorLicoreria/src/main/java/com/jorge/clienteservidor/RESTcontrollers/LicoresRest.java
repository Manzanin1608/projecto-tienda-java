package com.jorge.clienteservidor.RESTcontrollers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jorge.clienteservidor.modelo.Licor;
import com.jorge.clienteservidor.servicios.ServicioLicor;

@RestController
@RequestMapping("LicoresREST/")
public class LicoresRest {

	@Autowired
	private ServicioLicor servicioLicor;
	
	@RequestMapping("obtener")
	public List<Map<String, Object>> obtenerLibros() {
		//return servicioLicor.obtenerLicores();
		return servicioLicor.obtenerLicoresParaFormarJson();
	}
}
