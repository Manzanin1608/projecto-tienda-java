package com.jorge.clienteservidor.controllers.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jorge.clienteservidor.modelo.Licor;
import com.jorge.clienteservidor.modelo.Usuario;
import com.jorge.clienteservidor.servicios.ServicioCategoria;
import com.jorge.clienteservidor.servicios.ServicioUsuarios;

@Controller
@RequestMapping("admin/")
public class UsuariosController {

	@Autowired
	private ServicioUsuarios servicioUsuarios;
	
	@Autowired
	private ServicioCategoria servicioCategoria;
	
	
	@RequestMapping("guardarCambioUsuario")
	public String guardarCambioUsuario(@ModelAttribute("licorEditar") Usuario user,BindingResult resultadoValidaciones, Model model ) {
		if(resultadoValidaciones.hasErrors()) {
			return "admin/editarUsuario";
		}
		servicioUsuarios.actualizarUsuario(user);
		return obtenerLicores(model);
	}
	
	
	@RequestMapping("editarUsuario")
	public String editarLicor(@RequestParam("id") Long id, Model model) {
		Usuario user = servicioUsuarios.obtenerUsuarioPorId(id);
		model.addAttribute("UsuarioEditar",user);
		return "admin/editarUsuario";
	}
	
	
	@RequestMapping("obtenerUsuarios")
	public String obtenerLicores(Model model) {
		model.addAttribute("usuarios", servicioUsuarios.obtenerUsuarios());
		return "admin/usuarios";
	}
	
	@RequestMapping("borrarUsuario")
	public String borrarLibro(@RequestParam("id") Long id, Model model) {
		servicioUsuarios.borrarUsuario(id);
		return obtenerLicores(model);
	}
	
}
