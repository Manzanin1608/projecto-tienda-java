package com.jorge.clienteservidor.serviciosJPAImpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jorge.clienteservidor.modelo.Usuario;
import com.jorge.clienteservidor.servicios.ServicioUsuarios;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
@Transactional
public class ServicioUsuariosImpl implements ServicioUsuarios {
	// Vamos a implementar esta clase usando JPA

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void registrarUsuario(Usuario usuario) {
		entityManager.persist(usuario);
	}

	@Override
	public List<Usuario> obtenerUsuarios() {
		// ahora en JPA no hay criteria
		// para obtener datos y hacer consultas:
		// SQL nativo
		// JPQL -> pseudo SQL, muy sencillo, devuelve objetos
		List<Usuario> usuarios = entityManager.createQuery("SELECT u FROM usuario as u").getResultList();
		return usuarios;
	}

	@Override
	public void borrarUsuario(long id) {
		Usuario usuarioAborrar = obtenerUsuarioPorId(id);
		if(usuarioAborrar != null) {
			entityManager.createNativeQuery("DELETE FROM PRODUCTO_PEDIDO WHERE PEDIDO_ID IN (SELECT ID FROM PEDIDO WHERE USUARIO_ID = :id)").setParameter("id", id).executeUpdate();
			entityManager.createNativeQuery("DELETE FROM carrito WHERE usuario_id = :id").setParameter("id", id).executeUpdate();
			entityManager.createNativeQuery("DELETE FROM pedido WHERE usuario_id = :id").setParameter("id", id).executeUpdate();
			entityManager.remove(usuarioAborrar);
		}
		
	}

	@Override
	public Usuario obtenerUsuarioPorId(long id) {
		return entityManager.find(Usuario.class, id);
	}

	@Override
	public void actualizarUsuario(Usuario usuarioEditar) {
		entityManager.merge(usuarioEditar);

	}

	@Override
	public Usuario obtenerUsuarioPorEmailYpass(String email, String pass) {
		Usuario usuario = (Usuario) entityManager.createQuery("SELECT u FROM usuario as u WHERE u.email = :email and u.pass = :pass").
				setParameter("email", email).
				setParameter("pass", pass).getSingleResult();
		return usuario;
	}
	
	@Override
	public Usuario obtenerUsuarioPorEmail(String email) {
		try {
			Usuario usuario = (Usuario) entityManager.createQuery("SELECT u FROM usuario as u WHERE u.email = :email").
					setParameter("email", email).getSingleResult();
			return usuario;
		} catch (Exception e) {
			System.out.println("hay un usuario con el email indicado");
		}

		return null;
	}

}
