package com.jorge.clienteservidor.setUp;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jorge.clienteservidor.modelo.Usuario;
import com.jorge.clienteservidor.modelo.Carrito;
import com.jorge.clienteservidor.modelo.Categoria;
import com.jorge.clienteservidor.modelo.Licor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;



@Service
@Transactional
public class SetUpImpl implements SetUp{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void prepararRegistros() {
		TablaSetUp registroSetUp = null;
		//si no hay un registro en la tabla set up, preparamos registros iniciales
		try {
			registroSetUp = (TablaSetUp) entityManager.createQuery("SELECT r FROM TablaSetUp r").getSingleResult();
		} catch (Exception e) {
			System.out.println("No se encontro ningun registro en la tabla setup, "
					+"comenzamos a realizar los registros iniciales...");
		}
		if(registroSetUp != null && registroSetUp.isCompletado()) {
			return;
		}
		Categoria fermentado = new Categoria("Fermentados","Se obtienen por fermentación natural de azúcares presentes en frutas, cereales o mie"); 
		entityManager.persist(fermentado);
		Categoria destilado = new Categoria("Destilados", "Se producen destilando líquidos fermentados para concentrar el alcohol"); 
		entityManager.persist(destilado);
		Categoria fortificado = new Categoria("Fortificados", "Son vinos a los que se les añade alcohol extra"); 
		entityManager.persist(fortificado);
		Categoria licor = new Categoria("Licores y cremas", "Bebidas destiladas mezcladas con azúcar, hierbas, frutas o crema");
		entityManager.persist(licor);
		
		
		
		// Preparamos los registros iniciales
		Licor licor1 = new Licor("Triple Sec", "Cointreau", "Cointreau", 25.0, 40.00, "Licor de naranja usado en cócteles como Margarita y Cosmopolitan", "Francia");
		licor1.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/1.jpg"));
		licor1.setCategoria(licor);
		entityManager.persist(licor1);

		Licor licor2 = new Licor("Amaretto", "Disaronno Amaretto", "Disaronno", 22.00, 28.00, "Licor de almendras con notas de melocotón, ideal como digestivo o en repostería", "Italia");
		licor2.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/2.jpg"));
		licor2.setCategoria(licor);
		entityManager.persist(licor2);

		Licor licor3 = new Licor("Licor de Avellana", "Frangelico", "Frangelico", 20.00, 20.00, "Licor de avellanas con cacao, café y vainilla, usado como digestivo o en postres", "Italia");
		licor3.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/3.jpg"));
		licor3.setCategoria(licor);
		entityManager.persist(licor3);

		Licor licor4 = new Licor("Licor de Hierbas", "Amaro Meletti", "Meletti", 18.00, 32.00, "Digestivo italiano con anís y azafrán, sabor amargo con notas de chocolate", "Italia");
		licor4.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/4.jpg"));
		licor4.setCategoria(licor);
		entityManager.persist(licor4);

		Licor licor5 = new Licor("Licor de Tequila", "Agavero", "Agavero", 24.00, 32.00, "Licor a base de tequila con flor de Damiana, suave y aromático", "México");
		licor5.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/5.jpg"));
		licor5.setCategoria(licor);
		entityManager.persist(licor5);

		Licor licor6 = new Licor("Licor de Huevo", "Advocaat", "Bols", 19.00, 15.00, "Licor holandés de yema de huevo, brandy y vainilla, similar al ponche de huevo", "Países Bajos");
		licor6.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/6.jpg"));
		licor6.setCategoria(licor);
		entityManager.persist(licor6);

		Licor licor7 = new Licor("Licor de Anís", "Absente", "Absente", 27.00, 55.00, "Licor verde con sabor a anís, sustituto moderno de la absenta", "Francia");
		licor7.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/7.jpg"));
		licor7.setCategoria(licor);
		entityManager.persist(licor7);

		Licor licor8 = new Licor("Whisky", "Johnnie Walker Black Label", "Johnnie Walker", 35.00, 40.00, "Whisky escocés blended con notas de vainilla y turba", "Escocia");
		licor8.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/8.jpg"));
		licor8.setCategoria(destilado);
		entityManager.persist(licor8);

		Licor licor9 = new Licor("Whisky", "Jameson Irish Whiskey", "Jameson", 30.00, 40.00, "Whisky irlandés suave y triple destilado", "Irlanda");
		licor9.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/9.jpg"));
		licor9.setCategoria(destilado);
		entityManager.persist(licor9);

		Licor licor10 = new Licor("Ron", "Ron Zacapa 23", "Zacapa", 45.00, 40.00, "Ron guatemalteco añejado en sistema solera, con notas de miel y frutas secas", "Guatemala");
		licor10.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/10.jpg"));
		licor10.setCategoria(destilado);
		entityManager.persist(licor10);

		Licor licor11 = new Licor("Ron", "Havana Club Añejo 7 Años", "Havana Club", 28.00, 40.00, "Ron cubano oscuro con sabor intenso y especiado", "Cuba");
		licor11.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/11.jpg"));
		licor11.setCategoria(destilado);
		entityManager.persist(licor11);

		Licor licor12 = new Licor("Vodka", "Belvedere Vodka", "Belvedere", 42.00, 40.00, "Vodka polaco premium elaborado con centeno y agua pura", "Polonia");
		licor12.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/12.jpg"));
		licor12.setCategoria(destilado);
		entityManager.persist(licor12);

		Licor licor13 = new Licor("Vodka", "Absolut Vodka", "Absolut", 20.00, 40.00, "Vodka sueco suave y versátil, ideal para cócteles", "Suecia");
		licor13.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/13.jpg"));
		licor13.setCategoria(destilado);
		entityManager.persist(licor13);

		Licor licor14 = new Licor("Ginebra", "Tanqueray London Dry", "Tanqueray", 25.00, 47.30, "Ginebra clásica con fuerte presencia de enebro", "Reino Unido");
		licor14.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/14.jpg"));
		licor14.setCategoria(destilado);
		entityManager.persist(licor14);

		Licor licor15 = new Licor("Ginebra", "Hendrick's Gin", "Hendrick's", 38.00, 44.00, "Ginebra escocesa con infusión de pepino y pétalos de rosa", "Escocia");
		licor15.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/15.jpg"));
		licor15.setCategoria(destilado);
		entityManager.persist(licor15);

		Licor licor16 = new Licor("Tequila", "Don Julio Reposado", "Don Julio", 40.00, 38.00, "Tequila reposado suave con notas de caramelo y cítricos", "México");
		licor16.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/16.jpg"));
		licor16.setCategoria(destilado);
		entityManager.persist(licor16);

		Licor licor17 = new Licor("Tequila", "Patrón Silver", "Patrón", 45.00, 40.00, "Tequila blanco premium con sabor limpio y herbal", "México");
		licor17.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/17.jpg"));
		licor17.setCategoria(destilado);
		entityManager.persist(licor17);

		Licor licor18 = new Licor("Cognac", "Hennessy VS", "Hennessy", 39.00, 40.00, "Cognac francés joven con notas de roble y frutas", "Francia");
		licor18.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/18.jpg"));
		licor18.setCategoria(destilado);
		entityManager.persist(licor18);

		Licor licor19 = new Licor("Brandy", "Torres 10 Gran Reserva", "Torres", 18.00, 38.00, "Brandy español envejecido con sabor intenso y especiado", "España");
		licor19.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/19.jpg"));
		licor19.setCategoria(destilado);
		entityManager.persist(licor19);

		Licor licor20 = new Licor("Licor de Café", "Kahlúa", "Kahlúa", 20.00, 20.00, "Licor mexicano de café, ideal para cócteles como el Espresso Martini", "México");
		licor20.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/20.jpg"));
		licor20.setCategoria(licor);
		entityManager.persist(licor20);

		Licor licor21 = new Licor("Licor de Menta", "Creme de Menthe", "DeKuyper", 15.00, 25.00, "Licor verde de menta, usado en cócteles y postres", "Países Bajos");
		licor21.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/21.jpg"));
		licor21.setCategoria(licor);
		entityManager.persist(licor21);

		Licor licor22 = new Licor("Licor de Coco", "Malibu", "Malibu", 17.00, 21.00, "Licor de ron con sabor a coco, ideal para cócteles tropicales", "Barbados");
		licor22.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/22.jpg"));
		licor22.setCategoria(licor);
		entityManager.persist(licor22);

		Licor licor23 = new Licor("Licor de Melón", "Midori", "Midori", 22.00, 20.00, "Licor japonés de melón, vibrante y dulce", "Japón");
		licor23.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/23.jpg"));
		licor23.setCategoria(licor);
		entityManager.persist(licor23);

		Licor licor24 = new Licor("Licor de Durazno", "Peachtree", "DeKuyper", 16.00, 20.00, "Licor de melocotón, muy usado en cócteles frutales", "Países Bajos");
		licor24.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/24.jpg"));
		licor24.setCategoria(licor);
		entityManager.persist(licor24);

		Licor licor25 = new Licor("Licor de Frambuesa", "Chambord", "Chambord", 30.00, 16.50, "Licor francés de frambuesa con vainilla y miel", "Francia");
		licor25.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/25.jpg"));
		licor25.setCategoria(licor);
		entityManager.persist(licor25);

		Licor licor26 = new Licor("Licor de Crema", "Baileys Irish Cream", "Baileys", 19.00, 17.00, "Licor de crema irlandesa con whisky y cacao", "Irlanda");
		licor26.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/26.jpg"));
		licor26.setCategoria(licor);
		entityManager.persist(licor26);

		Licor licor27 = new Licor("Absenta", "Pernod Absinthe", "Pernod", 33.00, 68.00, "Licor de ajenjo con alto contenido alcohólico y sabor anisado", "Francia");
		licor27.setImagenPortada(obtenerInfoImagen("http://localhost:8080/img/licores/27.jpg"));
		licor27.setCategoria(destilado);
		entityManager.persist(licor27);


		//////////////////////////////////////////////////////////////////////////////////////////////////
		Usuario usuario1 = new Usuario("admin","123","admin@gmail.com","España",25);
		entityManager.persist(usuario1);
		Usuario usuario2 = new Usuario("marta", "abc123", "marta@gmail.com", "España", 30);
		entityManager.persist(usuario2);
		Usuario usuario3 = new Usuario("carlos", "pass456", "carlos@gmail.com", "México", 28);
		entityManager.persist(usuario3);
		Usuario usuario4 = new Usuario("laura", "qwerty", "laura@gmail.com", "Argentina", 35);
		entityManager.persist(usuario4);
		Usuario usuario5 = new Usuario("david", "secure789", "david@gmail.com", "Chile", 40);
		entityManager.persist(usuario5);
		//////////////////////////////////////////////////////////////////////////////////////////////////
		Carrito registroCarrito = new Carrito();
		registroCarrito.setUsuario(usuario3);
		registroCarrito.setLicor(licor5);
		registroCarrito.setCantidad(5);
		entityManager.persist(registroCarrito);
		Carrito registroCarrito2 = new Carrito();
		registroCarrito2.setUsuario(usuario4);
		registroCarrito2.setLicor(licor2);
		registroCarrito2.setCantidad(2);
		entityManager.persist(registroCarrito2);
		
		
		//una vez preparados los registros iniciales,
		//marcamos el setup completado de la siguienre forma;
		TablaSetUp registro = new TablaSetUp();
		registro.setCompletado(true);
		entityManager.persist(registro);

	}// end prepararRegistros
	
	//metodo que nos va a permitir opterner un byte[] de cada archivo
	//de imagenes_base
	private byte[] obtenerInfoImagen(String rutaOrigen) {
		byte[] info = null;
		try {
			URL url = new URL(rutaOrigen);
			info = IOUtils.toByteArray(url);
		} catch (IOException e) {
			System.out.println("No se pudo precesar: "+rutaOrigen);
			e.printStackTrace();
		}
		return info;
	}
	
}
