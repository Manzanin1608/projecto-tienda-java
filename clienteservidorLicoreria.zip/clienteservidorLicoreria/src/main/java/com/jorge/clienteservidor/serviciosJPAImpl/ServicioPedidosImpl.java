package com.jorge.clienteservidor.serviciosJPAImpl;

import java.lang.ScopedValue.Carrier;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jorge.clienteservidor.RESTcontrollers.datos.ResumenPedidio;
import com.jorge.clienteservidor.constantes.Estados;
import com.jorge.clienteservidor.constantesSQL.ConstantesSQL;
import com.jorge.clienteservidor.modelo.Carrito;
import com.jorge.clienteservidor.modelo.Pedido;
import com.jorge.clienteservidor.modelo.ProductoPedido;
import com.jorge.clienteservidor.modelo.Usuario;
import com.jorge.clienteservidor.servicios.ServicioCarrito;
import com.jorge.clienteservidor.servicios.ServicioPedidos;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;


@Service
@Transactional
public class ServicioPedidosImpl implements ServicioPedidos{

	@Autowired
	private ServicioCarrito servicioCarrito;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Pedido> obtenerPedidos() {
		return entityManager.createQuery("select p from Pedido p order by p.id desc").getResultList();
	}

	@Override
	public Pedido obtenerPedidoPorId(int idPedido) {
		return (Pedido) entityManager.find(Pedido.class, idPedido);
	}

	@Override
	public void actualizarPedido(int idPedido, String estado) {
		// Pedido p = obtenerPedidoPorId(idPedido); 
		Pedido p = (Pedido) entityManager.find(Pedido.class, idPedido);
		p.setEstado(estado);
		entityManager.merge(p);
		
	}
	
	
	@Override
	public void procesarPaso1(String nombre, String direccion, String provincia,String cp,String email,String tel, long idUsuario) {
		Pedido p = obtenerPedidoIncompletoActual(idUsuario);
		p.setNombreCompleto(nombre);
		p.setDireccion(direccion);
		p.setProvincia(provincia);
		p.setCp(cp);
		p.setEmail(email);
		p.setTelefono(tel);
		entityManager.merge(p);
		
	}

	@Override
	public ResumenPedidio procesarPaso2(String tarjeta, String numero, String titular, long idUsuario) {
		Pedido p = obtenerPedidoIncompletoActual(idUsuario);
		p.setNumeroTarjeta(numero);
		p.setTipoTarjeta(tarjeta);
		p.setTitularTarjeta(titular);
		entityManager.merge(p);
		
		//preparamos el ResumenPedido a devolver
		
		return obtenerResumenDelPedido(idUsuario);
	}
	
	@Override
	public void procesarPasoExtra(String fav, long idUsuario) {
		Pedido p = obtenerPedidoIncompletoActual(idUsuario);
		p.setFav(fav);
		entityManager.merge(p);
	}
	
	
	@Override
	public void confirmarPedido(long idUsuario) {
		Pedido p = obtenerPedidoIncompletoActual(idUsuario);
		//obtener los productos en el carrito para meterlos en el productosPedidos
		Usuario u = entityManager.find(Usuario.class, idUsuario);
		List<Carrito> c = entityManager.createQuery("SELECT c FROM Carrito c WHERE c.usuario.id = :usuario_id")
				.setParameter("usuario_id", idUsuario).getResultList();
		for(Carrito productoCarrito : c) {
			ProductoPedido pp = new ProductoPedido();
			pp.setCantidad(productoCarrito.getCantidad());
			pp.setLicor(productoCarrito.getLicor());
			pp.setPedido(p);
			entityManager.persist(pp);
		}
		p.setEstado(Estados.TERMINADO.name());
		entityManager.merge(p);
		//eliminar los productos de carrito
		entityManager.createNativeQuery(ConstantesSQL.SQL_VACIAR_CARRITO).setParameter("usuario_id", idUsuario).executeUpdate();

	}
	
	
	
	private ResumenPedidio obtenerResumenDelPedido(long idUsuario) {
		ResumenPedidio resumen = new ResumenPedidio();
		Pedido p = obtenerPedidoIncompletoActual(idUsuario);
		resumen.setNombreCompleto(p.getNombreCompleto());
		resumen.setDireccion(p.getDireccion());
		resumen.setProvincia(p.getProvincia());
		resumen.setCp(p.getCp());
		resumen.setEmail(p.getEmail());
		resumen.setTelefono(p.getTelefono());
		resumen.setTipoTarjeta(p.getTipoTarjeta());
		resumen.setTitularTarjeta(p.getTitularTarjeta());
		resumen.setNumeroTarjeta(p.getNumeroTarjeta());
		resumen.setFav(p.getFav());
		resumen.setLicores(servicioCarrito.obtenerProductosCarrito(idUsuario));
		return resumen;
	}

	
	
	
	//este metodo devuelve el pedido incompleto actual del usuario,
	//si no existe, lo creamos
	private Pedido obtenerPedidoIncompletoActual(long idUsuario) {
		Usuario usuario = entityManager.find(Usuario.class, idUsuario);
		Object pedidoIncompleto = null;
		List<Pedido> pedidos = entityManager.createQuery("select p from Pedido p where p.estado = :estado and p.usuario.id = :usuario_id")
				.setParameter("estado", Estados.INCOMPLETO.name())
				.setParameter("usuario_id", idUsuario).getResultList();
		if(pedidos.size() == 1) {
			pedidoIncompleto = pedidos.get(0);
		}
		Pedido pedido = null;
		if(pedidoIncompleto != null) {
			pedido = (Pedido) pedidoIncompleto;
		}else {
			pedido = new Pedido();
			pedido.setEstado(Estados.INCOMPLETO.name());
			pedido.setUsuario(usuario);
		}
		return pedido;
	}


}
